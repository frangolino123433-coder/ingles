# English, at your pace

A mobile-friendly English study site with interactive vocabulary cards, modal word explanations, animated English phrases, dialogue ordering by drag-and-drop (plus up/down buttons for touch screens), vocabulary/exercise tabs, multiple-choice quizzes, and typed practice.

## Run locally
Open `index.html` in a browser.

## Publish on GitHub Pages
Upload `index.html` to the root of a GitHub repository, then enable GitHub Pages in Settings → Pages.

Progress is stored locally in the browser; no account or backend is needed.
